// Este arquivo é um placeholder para testes
// Os testes reais serão implementados posteriormente 