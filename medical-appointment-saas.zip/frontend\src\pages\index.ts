export { default as DiagnosisAssistantPage } from './DiagnosisAssistantPage';
export { default as DashboardPage } from './DashboardPage';
export { default as AppointmentsPage } from './AppointmentsPage';
export { default as PatientsPage } from './PatientsPage';
export { default as DoctorsPage } from './DoctorsPage';
export { default as SettingsPage } from './SettingsPage';
export { default as LoginPage } from './LoginPage';
